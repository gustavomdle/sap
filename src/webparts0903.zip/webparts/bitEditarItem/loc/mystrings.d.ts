declare interface IBitEditarItemWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BitEditarItemWebPartStrings' {
  const strings: IBitEditarItemWebPartStrings;
  export = strings;
}
