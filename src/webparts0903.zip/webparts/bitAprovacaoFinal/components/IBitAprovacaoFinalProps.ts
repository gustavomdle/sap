export interface IBitAprovacaoFinalProps {
  description: string;
}
