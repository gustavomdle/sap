export interface IBitDetalhesProps {
  description: string;
}
