import * as React from 'react';
import styles from './BitTodosItens.module.scss';
import { IBitTodosItensProps } from './IBitTodosItensProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as jquery from 'jquery';
import * as $ from "jquery";
import * as jQuery from "jquery";
import { sp, IItemAddResult, DateTimeFieldFormatType } from "@pnp/sp/presets/all";
//import BootstrapTable from 'react-bootstrap-table-next';
import "bootstrap";


import { allowOverscrollOnElement } from 'office-ui-fabric-react';
import { PrimaryButton, Stack, MessageBar, MessageBarType } from 'office-ui-fabric-react';

require("../../../../node_modules/bootstrap/dist/css/bootstrap.min.css");


export interface IReactGetItemsState {
  items: [
    {
      "BITNumero": "",
      "Title": "",
      "Status": "",
      "Produto": { "Title": "" },
      "Cliente": { "Title": "" },
      "Aplicacao": { "Title": "" },
      "Segmento": "",
      "Vers_x00e3_o_x0020_BIT": "",
      "Author": { "Title": "" },
      "Created": "",
    }],
}

export default class BitTodosItens extends React.Component<IBitTodosItensProps, IReactGetItemsState> {

  public constructor(props: IBitTodosItensProps, state: IReactGetItemsState) {
    super(props);
    this.state = {
      items: [
        {
          "BITNumero": "",
          "Title": "",
          "Status": "",
          "Produto": { "Title": "" },
          "Cliente": { "Title": "" },
          "Aplicacao": { "Title": "" },
          "Segmento": "",
          "Vers_x00e3_o_x0020_BIT": "",
          "Author": { "Title": "" },
          "Created": "",
        }
      ],
    };
  }


  public componentDidMount() {


    var reactHandler = this;

    jquery.ajax({
      url: `${this.props.siteurl}/_api/web/lists/getbytitle('BIT')/items?$expand=Produto,Cliente,Aplicacao,Author&$select=BITNumero,Title,Status,Produto/Title,Cliente/Title,Aplicacao/Title,Segmento,Vers_x00e3_o_x0020_BIT,Author/Title,Created`,
      type: "GET",
      headers: { 'Accept': 'application/json; odata=verbose;' },
      success: function (resultData) {

        console.log("resultData",resultData);

        var res = "";

        //var resultado = resultData.d.results;

        console.log("resultData.length",resultData.d.results.length);

        if (resultData.d.results.length > 0) {

          for (var i = 0; i < resultData.d.results.length; i++) {

            res += `<tr>
            <td scope="col">${resultData.d.results[i].BITNumero}</td>
            <td scope="col">${resultData.d.results[i].Title}</td>
            <td scope="col">${resultData.d.results[i].Status}</td>
            <td scope="col">{item.Produto.Title}</td>
            <td scope="col">{item.Cliente.Title}</td>
            <td scope="col">{item.Aplicacao.Title}</td>
            <td scope="col">${resultData.d.results[i].Segmento}</td>
            <td scope="col">${resultData.d.results[i].Vers_x00e3_o_x0020_BIT}</td>
            <td scope="col">{item.Author.Title}</td>
            <td scope="col">${resultData.d.results[i].Created}</td>
          </tr>`

          }

        }

        $("#itemContainer").html(res);
        console.log("res",res);



      },
      error: function (jqXHR, textStatus, errorThrown) {
      }
    });




  }





  public render(): React.ReactElement<IBitTodosItensProps> {


    return (

      <><br></br><div id="conteudo_grid">
        <div className="table-responsive">
          <table className="table table-hover">
            <thead className="thead-light ">
              <tr>
                <th scope="col">BIT Número</th>
                <th scope="col">Título</th>
                <th scope="col">Status</th>
                <th scope="col">Produto</th>
                <th scope="col">Cliente</th>
                <th scope="col">Aplicação</th>
                <th scope="col">Segmento</th>
                <th scope="col">Versão BIT</th>
                <th scope="col">Criado por</th>
                <th scope="col">Criado</th>
              </tr>
            </thead>
            <tbody id="itemContainer">
            </tbody>
          </table>
        </div>
        <hr />
        <div id="holder" className="holder">
        </div>
      </div></>


    );
  }
}
