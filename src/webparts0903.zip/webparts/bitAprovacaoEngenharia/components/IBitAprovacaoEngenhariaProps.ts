export interface IBitAprovacaoEngenhariaProps {
  description: string;
}
