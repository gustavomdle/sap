declare interface IBitAprovacaoFinalWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BitAprovacaoFinalWebPartStrings' {
  const strings: IBitAprovacaoFinalWebPartStrings;
  export = strings;
}
