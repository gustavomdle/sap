/* tslint:disable */
require("./BitTodosItens.module.css");
const styles = {
  bitTodosItens: 'bitTodosItens_df72cdff',
  container: 'container_df72cdff',
  row: 'row_df72cdff',
  column: 'column_df72cdff',
  'ms-Grid': 'ms-Grid_df72cdff',
  title: 'title_df72cdff',
  subTitle: 'subTitle_df72cdff',
  description: 'description_df72cdff',
  button: 'button_df72cdff',
  label: 'label_df72cdff'
};

export default styles;
/* tslint:enable */