/* tslint:disable */
require("./BitNovoItem.module.css");
const styles = {
  tableStyle: 'tableStyle_c3f0e08a',
  panelStyle: 'panelStyle_c3f0e08a',
  divStyle: 'divStyle_c3f0e08a',
  headerCaptionStyle: 'headerCaptionStyle_c3f0e08a',
  headerStyle: 'headerStyle_c3f0e08a',
  tableCaptionStyle: 'tableCaptionStyle_c3f0e08a',
  rowCaptionStyle: 'rowCaptionStyle_c3f0e08a',
  rowStyle: 'rowStyle_c3f0e08a',
  CellStyle: 'CellStyle_c3f0e08a',
  formControl: 'formControl_c3f0e08a',
  required: 'required_c3f0e08a'
};

export default styles;
/* tslint:enable */