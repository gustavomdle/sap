declare interface IBitDetalhesWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BitDetalhesWebPartStrings' {
  const strings: IBitDetalhesWebPartStrings;
  export = strings;
}
