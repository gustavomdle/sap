declare interface IBitAprovacaoEngenhariaWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BitAprovacaoEngenhariaWebPartStrings' {
  const strings: IBitAprovacaoEngenhariaWebPartStrings;
  export = strings;
}
