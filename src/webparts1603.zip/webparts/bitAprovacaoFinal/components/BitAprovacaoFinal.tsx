import * as React from 'react';
import styles from './BitAprovacaoFinal.module.scss';
import { IBitAprovacaoFinalProps } from './IBitAprovacaoFinalProps';
import { escape } from '@microsoft/sp-lodash-subset';

export default class BitAprovacaoFinal extends React.Component<IBitAprovacaoFinalProps, {}> {
  public render(): React.ReactElement<IBitAprovacaoFinalProps> {
    return (
      <div className={ styles.bitAprovacaoFinal }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>
              <span className={ styles.title }>Welcome to SharePoint!</span>
              <p className={ styles.subTitle }>Customize SharePoint experiences using Web Parts.</p>
              <p className={ styles.description }>{escape(this.props.description)}</p>
              <a href="https://aka.ms/spfx" className={ styles.button }>
                <span className={ styles.label }>Learn more</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
