/* tslint:disable */
require("./BitAprovacaoEngenharia.module.css");
const styles = {
  bitAprovacaoEngenharia: 'bitAprovacaoEngenharia_1c444503',
  container: 'container_1c444503',
  row: 'row_1c444503',
  column: 'column_1c444503',
  'ms-Grid': 'ms-Grid_1c444503',
  title: 'title_1c444503',
  subTitle: 'subTitle_1c444503',
  description: 'description_1c444503',
  button: 'button_1c444503',
  label: 'label_1c444503'
};

export default styles;
/* tslint:enable */