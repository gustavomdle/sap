import * as React from 'react';
import styles from './BitAprovacaoEngenharia.module.scss';
import { IBitAprovacaoEngenhariaProps } from './IBitAprovacaoEngenhariaProps';
import { escape } from '@microsoft/sp-lodash-subset';

export default class BitAprovacaoEngenharia extends React.Component<IBitAprovacaoEngenhariaProps, {}> {
  public render(): React.ReactElement<IBitAprovacaoEngenhariaProps> {
    return (
      <div className={ styles.bitAprovacaoEngenharia }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>
              <span className={ styles.title }>Welcome to SharePoint!</span>
              <p className={ styles.subTitle }>Customize SharePoint experiences using Web Parts.</p>
              <p className={ styles.description }>{escape(this.props.description)}</p>
              <a href="https://aka.ms/spfx" className={ styles.button }>
                <span className={ styles.label }>Learn more</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
