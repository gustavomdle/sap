declare interface IBitTodosItensWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BitTodosItensWebPartStrings' {
  const strings: IBitTodosItensWebPartStrings;
  export = strings;
}
