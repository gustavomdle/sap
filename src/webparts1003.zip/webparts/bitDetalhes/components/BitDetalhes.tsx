import * as React from 'react';
import styles from './BitDetalhes.module.scss';
import { IBitDetalhesProps } from './IBitDetalhesProps';
import { escape } from '@microsoft/sp-lodash-subset';
import * as jquery from 'jquery';
import * as $ from "jquery";
import * as jQuery from "jquery";
import { sp, IItemAddResult, DateTimeFieldFormatType } from "@pnp/sp/presets/all";
import "bootstrap";
import { UrlQueryParameterCollection, Version } from '@microsoft/sp-core-library';

require("../../../../node_modules/bootstrap/dist/css/bootstrap.min.css");

var _idBit;



export default class BitDetalhes extends React.Component<IBitDetalhesProps, {}> {


  public componentDidMount() {

    document
    .getElementById("btnEditar")
    .addEventListener("click", (e: Event) => this.enviarParaEdicao());

    var queryParms = new UrlQueryParameterCollection(window.location.href);
    _idBit = parseInt(queryParms.getValue("idBIT"));

    console.log("_idRCS", _idBit);

    jquery.ajax({
      url: `${this.props.siteurl}/_api/web/lists/getbytitle('BIT')/items?$expand=Produto,Cliente,Aplicacao,Author,Aprovador_x0020_Engenharia,AprovadorGeral,Destinat_x00e1_rios_x0020_Padr_x&$select=ID,Title,OrigemBIT,Descricao,Solucao,Observacao,Aprovador_x0020_Engenharia/Title,AprovadorGeral/Title,Destinat_x00e1_rios_x0020_Padr_x/Title,BITNumero,Status,Produto/Title,Cliente/Title,Aplicacao/Title,Segmento,Acao,Vers_x00e3_o_x0020_BIT,Author/Title,Created,statusbit&$filter= ID eq ` + _idBit,
      type: "GET",
      headers: { 'Accept': 'application/json; odata=verbose;' },
      success: function (resultData) {

        console.log("resultData", resultData);

        //var resultado = resultData.d.results;

        if (resultData.d.results.length > 0) {

          console.log();

          for (var i = 0; i < resultData.d.results.length; i++) {

            var txtProduto = "";
            var txtCliente = "";
            var txtAplicacao = "";
            var txtAprovadorEngenharia = "";
            var txtDestinatarios = "";
            var txtAprovadorGeral = "";

            for (var x = 0; x < resultData.d.results[i].Produto.results.length; x++) {

              if (x == resultData.d.results[i].Produto.results.length - 1) {

                txtProduto += resultData.d.results[i].Produto.results[x].Title;

              } else {

                txtProduto += resultData.d.results[i].Produto.results[x].Title + ", ";
              }

            }


            for (var x = 0; x < resultData.d.results[i].Cliente.results.length; x++) {

              if (x == resultData.d.results[i].Cliente.results.length - 1) {

                txtCliente += resultData.d.results[i].Cliente.results[x].Title;

              } else {

                txtCliente += resultData.d.results[i].Cliente.results[x].Title + ", ";
              }
            }


            for (var x = 0; x < resultData.d.results[i].Aplicacao.results.length; x++) {

              if (x == resultData.d.results[i].Aplicacao.results.length - 1) {

                txtAplicacao += resultData.d.results[i].Aplicacao.results[x].Title;
              } else {

                txtAplicacao += resultData.d.results[i].Aplicacao.results[x].Title + ", ";
              }
            }


            for (var x = 0; x < resultData.d.results[i].Aprovador_x0020_Engenharia.results.length; x++) {

              if (x == resultData.d.results[i].Aprovador_x0020_Engenharia.results.length - 1) {

                txtAprovadorEngenharia += resultData.d.results[i].Aprovador_x0020_Engenharia.results[x].Title;

              } else {

                txtAprovadorEngenharia += resultData.d.results[i].Aprovador_x0020_Engenharia.results[x].Title + ", ";
              }

            }

            for (var x = 0; x < resultData.d.results[i].Destinat_x00e1_rios_x0020_Padr_x.results.length; x++) {

              if (x == resultData.d.results[i].Destinat_x00e1_rios_x0020_Padr_x.results.length - 1) {

                txtDestinatarios += resultData.d.results[i].Destinat_x00e1_rios_x0020_Padr_x.results[x].Title;

              } else {

                txtDestinatarios += resultData.d.results[i].Destinat_x00e1_rios_x0020_Padr_x.results[x].Title + ", ";
              }

            }


            for (var x = 0; x < resultData.d.results[i].AprovadorGeral.results.length; x++) {

              if (x == resultData.d.results[i].AprovadorGeral.results.length - 1) {

                txtAprovadorGeral += resultData.d.results[i].AprovadorGeral.results[x].Title;

              } else {

                txtAprovadorGeral += resultData.d.results[i].AprovadorGeral.results[x].Title + ", ";
              }

            }


            console.log("txtAprovadorGeral", txtAprovadorGeral);

            //var bitNumero = resultData.d.results[i].BITNumero;
            var id = resultData.d.results[i].ID;
            var origemBIT = resultData.d.results[i].OrigemBIT;
            var title = resultData.d.results[i].Title;
            var descricao = resultData.d.results[i].Descricao;
            var solucao = resultData.d.results[i].Solucao;
            var observacao = resultData.d.results[i].Observacao;
            var segmento = resultData.d.results[i].Segmento;
            var acoes = resultData.d.results[i].Acao;
            var status = resultData.d.results[i].statusbit;
            var versaoBIT = resultData.d.results[i].Vers_x00e3_o_x0020_BIT;


            //var status = resultData.d.results[i].Status;
            //var segmento = resultData.d.results[i].Segmento;
            //
            //var author = resultData.d.results[i].Author.Title;
            //var created = resultData.d.results[i].Created;

            //console.log("created",created);

            //if (bitNumero == null) bitNumero = "";

            //if (status == null) status = "";
            //if (segmento == null) segmento = "";
            //if (versaoBIT == null) versaoBIT = "";
            //if (author == null) author = "";


            if (title == null) title = "";
            if (title == null) title = "";


            $("#txtTitulo").html(title);
            $("#txtOrigemBit").html(origemBIT);
            $("#txtProduto").html(txtProduto);
            $("#txtCliente").html(txtCliente);
            $("#txtAplicacao").html(txtAplicacao);
            $("#txtDescricao").html(descricao);
            $("#txtSolucao").html(solucao);
            $("#txtObservacao").html(observacao);
            $("#txtAprovadorEngenharia").html(txtAprovadorEngenharia);
            $("#txtDestinatarios").html(txtDestinatarios);
            $("#txtAprovadorGeral").html(txtAprovadorGeral);
            $("#txtAcoes").html(acoes);
            $("#txtSegmento").html(segmento);
            $("#txtStatus").html(status);
            $("#txtVersao").html(versaoBIT);


          }

        }


      },
      error: function (jqXHR, textStatus, errorThrown) {
      }
    });

  }


  public render(): React.ReactElement<IBitDetalhesProps> {
    return (


      <><div>

        <div className="container-fluid border" style={{ "width": "800px" }}>

          <div className="form-group">
            <div className="form-row">
              <div className="form-group col-md-6">
                <label htmlFor="txtTitulo">Título</label>
                <br></br><span className="text-info" id="txtTitulo"></span>
              </div>
              <div className="form-group col-md-4">
                <label htmlFor="txtStatus">Status</label>
                <br></br><span className="text-info" id="txtStatus"></span>
              </div>
              <div className="form-group col-md-2">
                <label htmlFor="txtStatus">Versão</label>
                <br></br><span className="text-info" id="txtVersao"></span>
              </div>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="txtOrigemBit">Origem BIT</label>
            <br></br><span className="text-info" id="txtOrigemBit"></span>
          </div>


          <div className="form-group">
            <label htmlFor="txtProduto">Produto</label>
            <br></br><span className="text-info" id="txtProduto"></span>
          </div>

          <div className="form-group">
            <label htmlFor="txtCliente">Cliente</label>
            <br></br><span className="text-info" id="txtCliente"></span>
          </div>

          <div className="form-group">
            <label htmlFor="txtAplicacao">Aplicação</label>
            <br></br><span className="text-info" id="txtAplicacao"></span>
          </div>


          <div className="form-group">
            <label htmlFor="txtDescricao">Descrição</label>
            <br></br><span className="text-info" id="txtDescricao"></span>
          </div>

          <div className="form-group">
            <label htmlFor="txtSolucao">Solução</label>
            <br></br><span className="text-info" id="txtSolucao"></span>
          </div>

          <div className="form-group">
            <label htmlFor="txtObservacao">Observação</label>
            <br></br><span className="text-info" id="txtObservacao"></span>
          </div>

          <div className="form-row">
            <div className="form-group col-md-6">
              <label htmlFor="txtAprovadorEngenharia">Aprovador Engenharia</label>
              <br></br><span className="text-info" id="txtAprovadorEngenharia"></span>
            </div>
            <div className="form-group col-md-6">
              <label htmlFor="txtDestinatarios">Destinatários Adicionais</label>
              <br></br><span className="text-info" id="txtDestinatarios"></span>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="txtAprovadorGeral">Aprovador Geral</label>
            <br></br><span className="text-info" id="txtAprovadorGeral"></span>
          </div>

          <div className="form-group">
            <div className="form-row">
              <div className="form-group col-md-6">
                <label htmlFor="txtSegmento">Segmento</label>
                <br></br><span className="text-info" id="txtSegmento"></span>
              </div>
              <div className="form-group col-md-6">
                <label htmlFor="txtAcoes">Ações</label>
                <br></br><span className="text-info" id="txtAcoes"></span>
              </div>
            </div>
          </div>

          <div className="form-group">
            <div className="form-row">
              <div className="form-group col-md-10">
                <label>Anexos</label>
              </div>
              <div className="form-group col-md-2">
              </div>
            </div>
          </div>

        </div>

      </div>


        <br></br><br></br>

          <button style={{ "margin": "2px" }}  type="submit" id="btnReprovar" className="btn btn-danger">Reprovar</button>
          <button style={{ "margin": "2px" }}  type="submit" id="btnEditar" className="btn btn-primary">Editar</button>
          <button style={{ "margin": "2px" }}  type="submit" id="btnAprovar" className="btn btn-success">Aprovar</button>
          <button style={{ "margin": "2px" }}  type="submit" id="btnVoltar" className="btn btn-secondary">Voltar</button>
        </>


          );
  }


  enviarParaEdicao() {

    var queryParms = new UrlQueryParameterCollection(window.location.href);
    _idBit = parseInt(queryParms.getValue("idBIT"));
  
    window.location.href = `Editar-BIT.aspx?idBIT=${_idBit}`;
  
  }
}


