/* tslint:disable */
require("./BitEditarItem.module.css");
const styles = {
  bitEditarItem: 'bitEditarItem_69b5f194',
  container: 'container_69b5f194',
  row: 'row_69b5f194',
  column: 'column_69b5f194',
  'ms-Grid': 'ms-Grid_69b5f194',
  title: 'title_69b5f194',
  subTitle: 'subTitle_69b5f194',
  description: 'description_69b5f194',
  button: 'button_69b5f194',
  label: 'label_69b5f194'
};

export default styles;
/* tslint:enable */