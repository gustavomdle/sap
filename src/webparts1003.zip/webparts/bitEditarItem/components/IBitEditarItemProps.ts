export interface IBitEditarItemProps {
  description: string;
}
