/* tslint:disable */
require("./BitEditarItem.module.css");
const styles = {
  tableStyle: 'tableStyle_f87aaf9f',
  panelStyle: 'panelStyle_f87aaf9f',
  divStyle: 'divStyle_f87aaf9f',
  headerCaptionStyle: 'headerCaptionStyle_f87aaf9f',
  headerStyle: 'headerStyle_f87aaf9f',
  tableCaptionStyle: 'tableCaptionStyle_f87aaf9f',
  rowCaptionStyle: 'rowCaptionStyle_f87aaf9f',
  rowStyle: 'rowStyle_f87aaf9f',
  CellStyle: 'CellStyle_f87aaf9f',
  formControl: 'formControl_f87aaf9f',
  required: 'required_f87aaf9f'
};

export default styles;
/* tslint:enable */