declare interface IBitNovoItemWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BitNovoItemWebPartStrings' {
  const strings: IBitNovoItemWebPartStrings;
  export = strings;
}
