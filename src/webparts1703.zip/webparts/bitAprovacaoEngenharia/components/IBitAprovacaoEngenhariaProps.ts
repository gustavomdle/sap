import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IBitAprovacaoEngenhariaProps {
  description: string;
  siteurl: string;
  context: WebPartContext;
  statusBIT: string;
}
