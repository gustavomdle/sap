/* tslint:disable */
require("./BitAprovacaoFinal.module.css");
const styles = {
  bitAprovacaoFinal: 'bitAprovacaoFinal_a5c34d96',
  container: 'container_a5c34d96',
  row: 'row_a5c34d96',
  column: 'column_a5c34d96',
  'ms-Grid': 'ms-Grid_a5c34d96',
  title: 'title_a5c34d96',
  subTitle: 'subTitle_a5c34d96',
  description: 'description_a5c34d96',
  button: 'button_a5c34d96',
  label: 'label_a5c34d96'
};

export default styles;
/* tslint:enable */