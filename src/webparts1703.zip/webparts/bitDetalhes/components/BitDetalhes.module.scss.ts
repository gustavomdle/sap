/* tslint:disable */
require("./BitDetalhes.module.css");
const styles = {
  bitDetalhes: 'bitDetalhes_c3bab71d',
  container: 'container_c3bab71d',
  row: 'row_c3bab71d',
  column: 'column_c3bab71d',
  'ms-Grid': 'ms-Grid_c3bab71d',
  title: 'title_c3bab71d',
  subTitle: 'subTitle_c3bab71d',
  description: 'description_c3bab71d',
  button: 'button_c3bab71d',
  label: 'label_c3bab71d'
};

export default styles;
/* tslint:enable */