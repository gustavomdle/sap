/* tslint:disable */
require("./BitNovoItem.module.css");
const styles = {
  tableStyle: 'tableStyle_42fac6d3',
  panelStyle: 'panelStyle_42fac6d3',
  divStyle: 'divStyle_42fac6d3',
  headerCaptionStyle: 'headerCaptionStyle_42fac6d3',
  headerStyle: 'headerStyle_42fac6d3',
  tableCaptionStyle: 'tableCaptionStyle_42fac6d3',
  rowCaptionStyle: 'rowCaptionStyle_42fac6d3',
  rowStyle: 'rowStyle_42fac6d3',
  CellStyle: 'CellStyle_42fac6d3',
  formControl: 'formControl_42fac6d3'
};

export default styles;
/* tslint:enable */